# House Plan Calculator - Native Android App
Open this directory in Android Studio and run 'app' on any Android phone or emulator.
Built with Kotlin and Jetpack Compose.
