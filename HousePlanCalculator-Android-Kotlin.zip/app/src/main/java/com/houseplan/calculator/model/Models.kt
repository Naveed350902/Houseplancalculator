package com.houseplan.calculator.model

enum class Language(val code: String, val displayName: String) {
    EN("en", "English"),
    UR("ur", "اردو")
}

enum class StaircasePosition(val id: String) {
    FRONT_RIGHT("front-right"),
    FRONT_LEFT("front-left"),
    SIDE_RIGHT("side-right"),
    SIDE_LEFT("side-left");

    companion object {
        fun fromId(id: String): StaircasePosition =
            values().firstOrNull { it.id == id } ?: FRONT_RIGHT
    }
}

enum class GatePosition(val id: String) {
    FRONT_LEFT("front-left"),
    FRONT_CENTER("front-center"),
    FRONT_RIGHT("front-right");

    companion object {
        fun fromId(id: String): GatePosition =
            values().firstOrNull { it.id == id } ?: FRONT_RIGHT
    }
}

enum class CourtyardOption(val id: String) {
    REAR("rear"),
    CENTRAL("central"),
    FRONT("front"),
    NONE("none");

    companion object {
        fun fromId(id: String): CourtyardOption =
            values().firstOrNull { it.id == id } ?: REAR
    }
}

enum class RoomCategory {
    BEDROOM, DRAWING, KITCHEN, BATHROOM, LOUNGE, PORCH, STAIRS, PASSAGE, DUCT, STORE
}

data class RoomSelection(
    val bedrooms: Int = 2,
    val bathrooms: Int = 2,
    val drawingRoom: Boolean = true,
    val kitchens: Int = 1,
    val hasStairs: Boolean = true,
    val livingLounge: Boolean = true,
    val carPorch: Boolean = true,
    val openBackyard: Boolean = true,
    val courtyard: CourtyardOption = CourtyardOption.REAR,
    val gatePosition: GatePosition = GatePosition.FRONT_RIGHT,
    val storeRoom: Boolean = false
)

data class PlotDimensions(
    val width: Float = 25f,
    val length: Float = 50f
)

data class PlacedRoom(
    val id: String,
    val nameEn: String,
    val nameUr: String,
    val category: RoomCategory,
    val x: Float,
    val y: Float,
    val w: Float,
    val h: Float,
    val areaSqFt: Int,
    val colorHex: String,
    val descriptionEn: String,
    val descriptionUr: String
)

data class WallSegment(
    val x1: Float, val y1: Float, val x2: Float, val y2: Float, val isExterior: Boolean
)

data class DoorOpening(
    val x: Float, val y: Float, val width: Float, val swingAngle: Float = 90f, val isVertical: Boolean = false, val swingDir: Int = 1
)

data class WindowOpening(
    val x: Float, val y: Float, val width: Float, val isVertical: Boolean = false
)

data class StaircaseDetails(
    val x: Float, val y: Float, val w: Float, val h: Float, val stepsCount: Int = 16, val position: StaircasePosition
)

data class GateOpening(
    val x: Float, val y: Float, val width: Float, val position: GatePosition
)

data class GeneratedLayout(
    val plotWidth: Float,
    val plotLength: Float,
    val totalPlotAreaSqFt: Int,
    val totalCoveredAreaSqFt: Int,
    val marla: Float,
    val rooms: List<PlacedRoom>,
    val walls: List<WallSegment>,
    val doors: List<DoorOpening>,
    val windows: List<WindowOpening>,
    val staircase: StaircaseDetails?,
    val staircasePosition: StaircasePosition,
    val entryPoint: GateOpening
)

data class SavedPlan(
    val id: String,
    val title: String,
    val plotWidth: Float,
    val plotLength: Float,
    val roomsConfig: RoomSelection,
    val staircasePosition: StaircasePosition,
    val createdAt: Long = System.currentTimeMillis(),
    val notes: String = ""
)
