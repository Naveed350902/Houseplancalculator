package com.houseplan.calculator.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF1D4ED8)
val BlueDark = Color(0xFF1E40AF)
val SkyAccent = Color(0xFF0284C7)
val SurfaceLight = Color(0xFFF8FAFC)

private val LightColorScheme = lightColorScheme(
    primary = BluePrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = BlueDark,
    secondary = SkyAccent,
    background = SurfaceLight,
    surface = Color.White,
    onSurface = Color(0xFF0F172A)
)

@Composable
fun HousePlanCalculatorTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LightColorScheme, content = content)
}
